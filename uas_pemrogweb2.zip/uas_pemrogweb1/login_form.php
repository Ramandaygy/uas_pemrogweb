<?php

// 1. Include File Konfigurasi (config.php):
@include 'config.php'; // Mengambil konfigurasi dari file config.php
// 2
session_start();

// 3.Penanganan Formulir Login:
if(isset($_POST['submit'])){  // Cek apakah formulir login telah dikirim

   //4. Melakukan pembersihan dan pencegahan SQL injection
   $name = mysqli_real_escape_string($conn, $_POST['name']);
   $email = mysqli_real_escape_string($conn, $_POST['email']);
   $pass = md5($_POST['password']);
   $cpass = md5($_POST['cpassword']);
   $user_type = $_POST['user_type'];

    // 5.Query untuk memeriksa apakah email dan password cocok
   $select = " SELECT * FROM db_user WHERE email = '$email' && password = '$pass' ";
   
    // Menjalankan query
   $result = mysqli_query($conn, $select);

   // 6. Jika ada hasil, artinya email dan password cocok
   if(mysqli_num_rows($result) > 0){
       
       // Mengambil data hasil query
      $row = mysqli_fetch_array($result);
      // 7. Penanganan Tipe Pengguna dan Pengalihan Halaman:
      // Memeriksa tipe pengguna dan mengarahkan ke halaman yang sesuai
      if($row['user_type'] == 'admin'){

         //8. Menyimpan Nama Pengguna dalam Sesi:
         $_SESSION['admin_name'] = $row['name'];
         header('location:home_admin.php');

      }elseif($row['user_type'] == 'user'){

         $_SESSION['user_name'] = $row['name'];
         header('location:user_page1.php');

      }
     
   }else{
      // 9.Pesan Kesalahan:
      // Jika tidak ada hasil, maka email atau password salah
      $error[] = 'incorrect email or password!';
   }

};
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>login form</title>

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<div class="form-container">

   <form action="" method="post">
      <h3>login now</h3>
      <?php
      if(isset($error)){ // 11.Menampilkan Pesan Kesalahan:
         foreach($error as $error){
            echo '<span class="error-msg">'.$error.'</span>';
         };
      };
      // 12.Tautan Pendaftaran:
      ?> 
      <input type="email" name="email" required placeholder="enter your email">
      <input type="password" name="password" required placeholder="enter your password">
      <input type="submit" name="submit" value="login now" class="form-btn">
      <p>don't have an account? <a href="register_form.php">register now</a></p> 
   </form>

</div>

</body>
</html>