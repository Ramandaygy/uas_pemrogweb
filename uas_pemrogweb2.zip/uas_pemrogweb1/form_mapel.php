<!DOCTYPE html>
<html>
<head>
    <title>Form Input Mata Pelajaran</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f0f0f0;
            font-family: Arial, sans-serif;
            padding-top: 50px;
            background: linear-gradient(to bottom, rgba(0,0,0,0.6), #f0f0f0); /* Gradasi dari hitam ke abu-abu */
        }

        .container {
            width: 50%;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        form {
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
        }

        .form-control {
            margin-bottom: 15px;
        }

        button {
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            background-color: #007bff;
            color: #fff;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Konten PHP Anda tetap ada di sini -->
        <?php
        //include file koneksi, untuk koneksi ke database
        include "config.php";

        //fungsi untuk mencegah inputan karakter yang tidak sesuai
        function input($data){
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $nama_mapel = input($_POST["nama_mapel"]);
            $id_guru = input($_POST["id_guru"]);
            $id_tingkatan = input($_POST["id_tingkatan"]);
            
            // Using prepared statements to prevent SQL injection
            $sql = "INSERT INTO mata_pelajaran (nama_mapel, id_guru, id_tingkatan) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sss", $nama_mapel, $id_guru, $id_tingkatan);
            $stmt->execute();
            $stmt->close();

            // Handle success or error messages
            if ($stmt) {
                echo "Data inserted successfully!";
            } else {
                echo "Error: " . $sql . "<br>" . $conn->error;
            }
        }
        ?>
        <h2>Input Data</h2>
        <form action="<?php echo $_SERVER["PHP_SELF"];?>" method="post">
            <div class="form-group">
                <label>Nama mapel:</label>
                <input type="text" name="nama_mapel" class="form-control" placeholder="Masukan Nama_mapel" required />
            </div>
            <div class="form-group">
                <label>Id guru:</label>
                <input type="text" name="id_guru" class="form-control" placeholder="Masukan Id guru" required />
            </div>
            <div class="form-group">
                <label>Id tingkatan:</label>
                <input type="text" name="id_tingkatan" class="form-control" placeholder="Masukan Id tingkatan" required />
            </div>
            <button type="submit" name="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>
</body>
</html>
