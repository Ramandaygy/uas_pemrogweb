<?php
// Redirect to a new page
header("Location: login_form.php");
exit(); // Ensure that following code is not executed
?>