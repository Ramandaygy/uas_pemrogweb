<?php
// // Memanggil file konfigurasi database
@include 'config.php';

// Memulai session
session_start();

// Menghapus semua variabel session
session_unset();

// Menghancurkan session
session_destroy();
// Mengarahkan pengguna ke halaman login_form.php
header('location:login_form.php');

?>