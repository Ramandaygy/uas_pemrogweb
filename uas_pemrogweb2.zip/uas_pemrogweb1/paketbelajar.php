<?php
//koneksi database
$server = "localhost";
$user = "root";
$password = "";
$database = "bimbel";

//buat koneksi
$koneksi = mysqli_connect($server, $user, $password, $database) or die(mysqli_error($koneksi));

//memulai sesi
session_start();

//jika tombol simpan diklik
if (isset($_POST['bsimpan'])) {
    //pengujian apakah data akan di edit atau disimpan baru
    if (isset($_GET['hal']) && $_GET['hal'] == "edit") {
        //data akan di edit
        $edit = mysqli_query($koneksi, "UPDATE paket_belajar SET nama_paket = '$_POST[tnama]', deskripsi = '$_POST[tdes]', biaya_pendidikan = '$_POST[tbiaya]', tahun_kurikulum = '$_POST[ttahun]', lama_studi = '$_POST[tlama]' WHERE id_paket_belajar = '$_GET[id]' ");

        //uji jika edit data sukses
        if ($edit) {
            echo "<script>
                alert('Edit data Sukses!');
                window.location.href = 'paketbelajar.php';
                </script>";
        } else {
            echo "<script>
                alert('Edit data Gagal!');
                window.location.href = 'paketbelajar.php';
                </script>";
        }
    } else {
        //Data akan disimpan baru
        $simpan = mysqli_query($koneksi, "INSERT INTO paket_belajar (nama_paket, deskripsi, biaya_pendidikan, tahun_kurikulum, lama_studi)
                                            VALUE ('$_POST[tnama]', '$_POST[tdes]', '$_POST[tbiaya]', '$_POST[ttahun]', '$_POST[tlama]')");
        //uji jika simpan data sukses
        if ($simpan) {
            echo "<script>
                alert('Simpan data Sukses!');
                window.location.href = 'paketbelajar.php';
                </script>";
        } else {
            echo "<script>
                alert('Simpan data Gagal!');
                window.location.href = 'paketbelajar.php';
                </script>";
        }
    }
}

//Deklarasi variabel untuk menampung data yang akan di edit
$vid = "";
$vnama = "";
$vdes = "";
$vbiaya = "";
$vtahun = "";
$vlama = "";

//pengujian jika tombol edit/hapus diklik
if (isset($_GET['hal'])) {
    //pengujian jika edit data
    if ($_GET['hal'] == "edit") {
        //tampilkan data yang akan di edit
        $tampil = mysqli_query($koneksi, "SELECT * FROM paket_belajar WHERE id_paket_belajar = '$_GET[id]' ");
        $data = mysqli_fetch_array($tampil);
        if ($data) {
            //jika data ditemukan maka data di tampung ke dalam variabel
            $vid = $data['id_paket_belajar'];
            $vnama = $data['nama_paket'];
            $vdes = $data['deskripsi'];
            $vbiaya = $data['biaya_pendidikan'];
            $vtahun = $data['tahun_kurikulum'];
            $vlama = $data['lama_studi'];
        }
    }
}

//pengujian jika tombol delete diklik
if (isset($_POST['delete'])) {
    $id = $_POST['id_paket_belajar'];

    try {
        // Attempt to delete the member record
        $delete_paket_belajar = mysqli_query($koneksi, "DELETE FROM paket_belajar WHERE id_paket_belajar = '$id'");

        if ($delete_paket_belajar) {
            echo "<script>
                alert('Hapus data Sukses!');
                window.location.href = 'paketbelajar.php';
                </script>";
        } else {
            throw new Exception("Gagal menghapus data paket belajar");
        }
    } catch (Exception $e) {
        // Handle the exception and set an appropriate error message
        echo "<script>
            alert('Gagal menghapus data paket belajar');
            window.location.href = 'paketbelajar.php';
            </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>DATA PAKET BELAJAR</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>

<body>
    <div class="container">
        <h3 class="text-center">DATA PAKET BELAJAR</h3>
        <h3 class="text-center">NEW PRIMAGAMA</h3>

        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="card">
                    <div class="card-header bg-info text-light">
                        FORM INPUT DATA PAKET BELAJAR
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label">ID paketbelajar</label>
                                <input type="text" name="tid" value="<?= $vid ?>" class="form-control" placeholder="Masukan ID paketbelajar">
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Nama</label>
                                <input type="text" name="tnama" value="<?= $vnama ?>" class="form-control" placeholder="Masukan Nama paket">
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Deskripsi</label>
                                <input type="text" name="tdes" value="<?= $vdes ?>" class="form-control" placeholder="Masukan Deskripsi">
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Biaya Pendidikan</label>
                                <input type="text" name="tbiaya" value="<?= $vbiaya ?>" class="form-control" placeholder="Masukan Biaya Pendidikan">
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Tahun Kurikulum</label>
                                <input type="text" name="ttahun" value="<?= $vtahun ?>" class="form-control" placeholder="Masukan Tahun Kurikulum">
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Lama Studi</label>
                                <input type="text" name="tlama" value="<?= $vlama ?>" class="form-control" placeholder="Masukan Lama Studi">
                            </div>
                    </div>
                    <div class="text-center">
                        <hr>
                        <button class="btn btn-primary" name="bsimpan" type="submit">Simpan</button>
                    </div>
                    <div class="card-footer bg-info"></div>
                </div>
            </div>
            </form>

            <div class="card mt-3">
                <div class="card-header bg-info text-light">
                    DATA PAKET BELAJAR
                </div>
                <table class="table table-striped table-hover table-bordered">
                    <tr>
                        <th>ID paketbelajar</th>
                        <th>Nama</th>
                        <th>Deskripsi</th>
                        <th>Biaya Pendidikan</th>
                        <th>Tahun Kurikulum</th>
                        <th>Lama Studi</th>
                        <th>Aksi</th>
                    </tr>
                    <?php
                    //persiapan menampilkan data
                    $no = 1;

                    //untuk pencarian data
                    //jika tombol cari diklik
                    if (isset($_POST['bcari'])) {
                        //tampilkan data yang dicari
                        $keyword = $_POST['tcari'];
                        $q = "SELECT * FROM paket_belajar order by id_paket_belajar asc";
                    } else {
                        $q = "SELECT * FROM paket_belajar order by id_paket_belajar asc";
                    }
                    $tampil = mysqli_query($koneksi, $q);
                    while ($data = mysqli_fetch_array($tampil)) {
                    ?>

                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= $data['nama_paket'] ?></td>
                            <td><?= $data['deskripsi'] ?></td>
                            <td><?= $data['biaya_pendidikan'] ?></td>
                            <td><?= $data['tahun_kurikulum'] ?></td>
                            <td><?= $data['lama_studi'] ?></td>
                            <td>
                                <a href="paketbelajar.php?hal=edit&id=<?= $data['id_paket_belajar'] ?>" class="btn btn-warning">Edit</a>
                            </td>
                            <td>
                                <form method="POST" action="paketbelajar.php">
                                    <input type="hidden" name="id_paket_belajar" value="<?= $data['id_paket_belajar'] ?>">
                                    <button class="btn btn-danger" name="delete" type="submit" onclick="return confirm('Apakah anda yakin akan hapus Data ini?')">Hapus</button>
                                </form>
                            </td>
                        </tr>

                    <?php } ?>
                </table>
            </div>
            <div class="card-footer bg-info"></div>
            <!-- Tombol kembali ke halaman utama -->
            <div class="mt-3">
                <a href="home_admin.php" class="btn btn-primary">Kembali ke Halaman Utama</a>
            </div>
        </div>
    </div>
    </div>
    </form>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>

</html>