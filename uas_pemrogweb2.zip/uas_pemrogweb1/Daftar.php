<?php
include "config.php";

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["daftar"])) {
    // Ambil data dari formulir
    $id_siswa = $_POST["id_siswa"];
    $nama_siswa = $_POST["nama_siswa"];
    $alamat = $_POST["alamat"];
    $no_kontak = $_POST["no_kontak"];
    $gender_id_gender = $_POST["gender_id_gender"];
    $paket_belajar_nama_paket = isset($_POST["paket_belajar_nama_paket"]) ? $_POST["paket_belajar_nama_paket"] : "";

    // Validasi data
    $error = array();

    // Contoh validasi NIS harus diisi
    if (empty($id_siswa)) {
        $error[] = "NIS harus diisi";
    }

    // Jika tidak ada kesalahan, simpan data ke database
    if (empty($error)) {
		$query = "INSERT INTO order_bimbel (id_siswa, nama_siswa, alamat, no_kontak, gender_id_gender, paket_belajar_nama_paket) 
		VALUES ('$id_siswa', '$nama_siswa', '$alamat', '$no_kontak', '$gender_id_gender', '$paket_belajar_nama_paket')";
        $result = mysqli_query($conn, $query);

        if ($result) {
            echo '<span class="success-msg">Pendaftaran berhasil!</span>';
        } else {
            echo '<span class="error-msg">Pendaftaran gagal. Silakan coba lagi.</span>';
        }
    } else {
        // Tampilkan pesan kesalahan
        foreach ($error as $errorMsg) {
            echo '<span class="error-msg">' . $errorMsg . '</span>';
        }
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>login form</title>

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style4.css">

</head>
<body>
   
<div class="form-container">
   <form action="" method="post">
      <h3>Daftar Bimbel</h3>
      <?php
      if(isset($error)){
         foreach($error as $error){
            echo '<span class="error-msg">'.$error.'</span>';
        };
      	};
      	?>
      		<table>
		  		<tr>
					<td>NIS</td>
					<td><input type="text" name="id_siswa" size="30" placeholder="Enter NIS"></td>
					
				</tr>
				<tr>
					<td>Nama</td>
					<td><input type="text" name="nama_siswa" size="30" placeholder="Enter Nama"></td>
				</tr>
				<tr>
					<td>Alamat</td>
					<td><input type="text" name="alamat" size="30" placeholder="Enter Alamat"></td>
				</tr>
				<tr>
					<td>No HP</td>
					<td><input type="tel" name="no_kontak" size="30" placeholder="Enter No HP"></td>
				</tr>
				<tr>
					<td>Gender</td>
					<td><select name="gender_id_gender">
						<option>---</option>
						<?php
							include "config.php";
							$query = mysqli_query($conn,"SELECT * FROM gender") or die (mysqli_error($conn));
							while($data = mysqli_fetch_array($query)){
								echo "<option value=$data[id_gender]> $data[gender] </option>";
							}
						?>
						</select>
                     </td>
				</tr>
				<tr>
					<td>Pilih Paket</td>
					<td><select name="paket_belajar_nama_paket">
						<option>---</option>
						<?php
							include "config.php";
							$query = mysqli_query($conn,"SELECT * FROM paket_belajar") or die (mysqli_error($conn));
							while($data = mysqli_fetch_array($query)){
								echo "<option value=$data[id_paket_belajar]> $data[nama_paket] </option>";
							}
						?>
						</select>
                    </td>
				</tr>
				<tr>
				<tr>
					<td colspan="2">
						<input type="submit" class="form-btn" name="daftar" value="Daftar">
					</td>
      				<a href="user_page2.php">Back To Home</a>
				</tr>
			</table>
	</form>		

	<?php
		if(isset($_POST['proses'])){

			mysqli_query($conn,"insert into siswa set
			nama_siswa = '$_POST[nama_siswa]',
			alamat = '$_POST[alamat]',
			no_kontak = '$_POST[id_gender]'") or die(mysqli_error($conn));
			
			echo "<script>alert('Data telah tersimpan')</script>";
		}	
	?>
</div>

</body>
</html>		
		