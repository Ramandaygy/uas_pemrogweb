<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    
    <title>Form Paket Belajar</title>
</head>
<body>
    <div class="container">
        <?php
        //include file koneksi ,untuk koneksikan ke database
        include "config.php";

        //fungsi untuk mencegah inputan karakter yang tidak sesuai
        function input($data){
            $data = trim($data);
            $data = stripcslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }

        //cek apakah ada kiriman form dari method post
        if($_SERVER["REQUEST_METHOD"]== "POST"){

            $idp_aket=input($_POST["id_paket"]);
            $nama_paket=input($_POST["nama_paket"]);
            $deskripsi=input($_POST["deskripsi"]);
            $biaya_pendidikan=input($_POST["biaya_pendidikan"]);
            $tahun_kurikulum=input($_POST["tahun_kurikulum"]);
            $lama_studi=input($_POST["lama_studi"]);

            //query input menginput data kedalam tabel anggota
            $sql="insert into paket belajar (id_paket,nama_paket,deskripsi,biaya_pendidikan,tahun_kurikulum,lama_studi) values
            ('$id_paket','$nama_paket','$deskripsi','$biaya_pendidikan','$tahun_kurikulum','$lama_studi')";

            //mengeksekusi query diatas
            $hasil=mysqli_query($conn,$sql);

            //kondisi apakah berhasil atua tidak
            if ($hasil){
                header("location:config.php");
            }
            else{
                echo  "<div class'alert alert-danger'> Data Gagal disimpan.</div>";
            }
        }
        ?>
        

        <h2 > CREATE PAKET BELAJAR</h2><br>

        <form action="<?php echo $_SERVER["PHP_SELF"];?>"method="post">
            <div class="form-group">
                <label>Id Paket:</label>
                <input type="text" name-"id_paket" class="form-control" placeholder="Masukan Id paket" required />

            </div>
            <div class="form-group">
                <label>Nama Paket:</label>
                <input type="text" name-"nama_paket" class="form-control" placeholder="Masukan nama paket" required />

            </div>
            <div class="form-group">
                <label>deskripsi:</label>
                <input type="text" name-"deskripsi" class="form-control" placeholder="Masukan deskripsi" required />

            </div>
            <div class="form-group">
                <label>Biaya Pendidikan:</label>
                <input type="text" name-"biaya_pendidikan" class="form-control" placeholder="Masukan biaya pendidikan" required />

            </div>
            <div class="form-group">
                <label>Tahun Kurikulum:</label>
                <input type="text" name-"tahun_kurikulum" class="form-control" placeholder="Masukan tahun kurikulum" required />

            </div>
            <div class="form-group">
                <label>Lama Studi:</label>
                <input type="text" name-"lama_studi" class="form-control" placeholder="Masukan lama studi" required />

            </div>
            <br>
            <br>
            <a href="create.php" class="btn btn-primary" role="button">Submit</a>
            
        </form>
    </div>
    
</body>
</html>