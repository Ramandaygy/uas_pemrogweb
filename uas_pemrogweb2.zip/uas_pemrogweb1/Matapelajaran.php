<!DOCTYPE html>
<html>
<head>
    <title>Form Input Mata Pelajaran</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css">
    <style>
        body {
            background-color: #f0f0f0;
            font-family: Arial, sans-serif;
            padding-top: 50px;
            background: linear-gradient(to bottom, rgba(0,0,0,0.6), #f0f0f0); /* Gradasi dari hitam ke abu-abu */
        }

        .container {
            width: 50%;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        form {
            margin-bottom: 20px;
        }

        label {
            font-weight: bold;
        }

        .form-control {
            margin-bottom: 15px;
        }

        button {
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            background-color: #007bff;
            color: #fff;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php
        //include file koneksi, untuk koneksi ke database
        include "config.php";

        // Inisialisasi variabel
        $id_mapel = "";
        $nama_mapel = "";
        $GURU_id_guru = "";
        $tingkatan_id_tingkatan = "";

        // Fungsi untuk mencegah inputan karakter yang tidak sesuai
        function input($data){
            $data = trim($data);
            $data = stripslashes($data);
            $data = htmlspecialchars($data);
            return $data;
        }

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $id_mapel = input($_POST["id_mapel"]);
            $nama_mapel = input($_POST["nama_mapel"]);
            $GURU_id_guru = input($_POST["GURU_id_guru"]);
            $tingkatan_id_tingkatan = input($_POST["tingkatan_id_tingkatan"]);
            
            // Using prepared statements to prevent SQL injection
            $sql = "INSERT INTO mata_pelajaran (id_mapel, nama_mapel, GURU_id_guru, tingkatan_id_tingkatan) VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            
            if (!$stmt) {
                echo "Error: " . $conn->error; // Tampilkan kesalahan jika persiapan query gagal
            } else {
                $stmt->bind_param("ssss", $id_mapel, $nama_mapel, $GURU_id_guru, $tingkatan_id_tingkatan);
                $stmt->execute();

                // Handle success or error messages
                if ($stmt->affected_rows > 0) {
                    echo "Data inserted successfully!";
                } else {
                    echo "Error: " . $stmt->error; // Tampilkan kesalahan jika eksekusi query gagal
                }
                $stmt->close();
            }
        }

        // Fungsi untuk menghapus data mata pelajaran berdasarkan ID
        if (isset($_GET['hal']) && $_GET['hal'] == 'hapus' && isset($_GET['id'])) {
            $id_mapel = input($_GET['id']);

            // Menghapus data berdasarkan id_mapel
            $sql_delete = "DELETE FROM mata_pelajaran WHERE id_mapel = ?";
            $stmt_delete = $conn->prepare($sql_delete);
            $stmt_delete->bind_param("s", $id_mapel);
            $stmt_delete->execute();
            $stmt_delete->close();

            // Redirect kembali ke halaman setelah penghapusan
            header("Location: {$_SERVER['PHP_SELF']}");
            exit();
        }

        // Fungsi untuk mode edit data mata pelajaran
if (isset($_GET['hal']) && $_GET['hal'] == 'edit' && isset($_GET['id'])) {
    $id_mapel = input($_GET['id']);

    // Mengambil data berdasarkan id_mapel untuk diedit
    $sql_edit = "SELECT * FROM mata_pelajaran WHERE id_mapel = ?";
    $stmt_edit = $conn->prepare($sql_edit);
    $stmt_edit->bind_param("s", $id_mapel);
    $stmt_edit->execute();
    $result_edit = $stmt_edit->get_result();

    if ($result_edit->num_rows > 0) {
        $row_edit = $result_edit->fetch_assoc();
        $id_mapel = $row_edit['id_mapel'];
        $nama_mapel = $row_edit['nama_mapel'];
        $GURU_id_guru = $row_edit['GURU_id_guru'];
        $tingkatan_id_tingkatan = $row_edit['tingkatan_id_tingkatan'];

        // Menyiapkan data untuk diedit dalam form
        echo "<script>
                document.getElementsByName('id_mapel')[0].value = '$id_mapel';
                document.getElementsByName('nama_mapel')[0].value = '$nama_mapel';
                document.getElementsByName('GURU_id_guru')[0].value = '$GURU_id_guru';
                document.getElementsByName('tingkatan_id_tingkatan')[0].value = '$tingkatan_id_tingkatan';
            </script>";
    } else {
        echo "Data tidak ditemukan!";
    }

    $stmt_edit->close();
}

// Proses update data setelah form diedit dan disubmit
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Ambil data yang dikirimkan melalui form
    $id_mapel = input($_POST['id_mapel']);
    $nama_mapel = input($_POST['nama_mapel']);
    $GURU_id_guru = input($_POST['GURU_id_guru']);
    $tingkatan_id_tingkatan = input($_POST['tingkatan_id_tingkatan']);

    // Query untuk melakukan update data
    $sql_update = "UPDATE mata_pelajaran SET nama_mapel = ?, GURU_id_guru = ?, tingkatan_id_tingkatan = ? WHERE id_mapel = ?";
    $stmt_update = $conn->prepare($sql_update);
    $stmt_update->bind_param("ssss", $nama_mapel, $GURU_id_guru, $tingkatan_id_tingkatan, $id_mapel);

    if ($stmt_update->execute()) {
        echo "Data berhasil diperbarui.";
        // Redirect atau tampilkan pesan sukses sesuai kebutuhan aplikasi Anda
    } else {
        echo "Terjadi kesalahan dalam memperbarui data: " . $conn->error;
        // Tindakan lain jika terjadi kesalahan, seperti menampilkan pesan kesalahan atau melakukan redirect kembali ke halaman edit
    }

    $stmt_update->close();
}

        ?>
        <!-- Form Input Data Mata Pelajaran -->
        <h2>Input Data</h2>
        <form action="<?php echo $_SERVER["PHP_SELF"];?>" method="post">
            <div class="form-group">
                <label>ID Mapel:</label>
                <input type="text" name="id_mapel" class="form-control" placeholder="Masukkan ID Mapel" value="<?php echo $id_mapel; ?>" required />
            </div>
            <div class="form-group">
                <label>Nama Mapel:</label>
                <input type="text" name="nama_mapel" class="form-control" placeholder="Masukkan Nama Mapel" value="<?php echo $nama_mapel; ?>" required />
            </div>
            <div class="form-group">
                <label>ID Guru:</label>
                <input type="text" name="GURU_id_guru" class="form-control" placeholder="Masukkan ID Guru" value="<?php echo $GURU_id_guru; ?>" required />
            </div>
            <div class="form-group">
                <label>ID Tingkatan:</label>
                <input type="text" name="tingkatan_id_tingkatan" class="form-control" placeholder="Masukkan ID Tingkatan" value="<?php echo $tingkatan_id_tingkatan; ?>" required />
            </div>
            <button type="submit" name="submit" class="btn btn-primary">Submit</button>
        </form>
    </div>

    <div class="card mt-3">
        <div class="card-header bg-info text-light">
            DATA MATA PELAJARAN
        </div>
        <table class="table table-striped table-hover table-bordered">
            <tr>
                <th>ID Mata Pelajaran</th>
                <th>Nama Mata Pelajaran</th>
                <th>ID Guru</th>
                <th>ID Tingkatan</th>
                <th>Aksi</th>
            </tr>
            <?php
            $sql = "SELECT * FROM mata_pelajaran";
            $result = mysqli_query($conn, $sql);
            
            if (!$result) {
                echo "Kesalahan dalam menjalankan kueri: " . mysqli_error($conn);
            } else {
                while ($data = mysqli_fetch_array($result)) {
                    echo "<tr>";
                    echo "<td>" . $data['id_mapel'] . "</td>";
                    echo "<td>" . $data['nama_mapel'] . "</td>";
                    echo "<td>" . $data['GURU_id_guru'] . "</td>";
                    echo "<td>" . $data['tingkatan_id_tingkatan'] . "</td>";
                    echo "<td>
                            <a href='Matapelajaran.php?hal=edit&id=" . $data['id_mapel'] . "' class='btn btn-primary'>Edit</a>
                            <a href='Matapelajaran.php?hal=hapus&id=" . $data['id_mapel'] . "' class='btn btn-success' onclick='return confirm(\"Apakah anda yakin akan hapus Data ini?\")'>Hapus</a>
                            </td>";
                    echo "</tr>";
                }
            }
            ?>
        </table>
    </div>
    <!-- Tombol kembali ke halaman utama -->
    <div class="mt-3">
            <a href="home_admin.php" class="btn btn-primary">Kembali ke Halaman Utama</a>
        </div>
</body>
</html>