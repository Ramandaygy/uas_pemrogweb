-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 13 Jan 2024 pada 02.30
-- Versi server: 10.4.25-MariaDB
-- Versi PHP: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bimbel`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `db_user`
--

CREATE TABLE `db_user` (
  `id_user` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `user_type` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `db_user`
--

INSERT INTO `db_user` (`id_user`, `name`, `email`, `password`, `user_type`) VALUES
(1, 'Adela Setiabudi Prawibowo', 'setiabudiq@gmail.com', 'e19d5cd5af0378da05f63f891c7467af', 'admin'),
(2, 'Alvaro', 'Alvaro@gmail.com', 'd0e46158db756016f8c42700c6bb1a89', 'user'),
(3, 'Bella Adha', 'bella@gmail.com', '993acec11ef1a181f9ac78f9a5b824ab', 'admin'),
(4, 'Simut', 'mutsi@gmail.com', '5281e2e43748e46574a2089f2030e5bf', 'user'),
(5, 'Ramanda', 'ramanda@gmail.com', '25af84a96fdf800f6ced94a9d1c2e81c', 'admin'),
(6, 'Setiabudi', 'setiabud2205@gmail.com', 'bfe84f9b258404dde399993f2933a7d9', 'admin'),
(7, 'bella', 'bellaadha@gmail.com', 'c2b9a64db6c5c5187f62f9f8871c1d1c', 'admin'),
(8, 'Wafa Lailatul', 'wafa@gmail.com', '8a9b6651e1c37d18e9ae263d8a2b83b9', 'admin');

-- --------------------------------------------------------

--
-- Struktur dari tabel `detil_paket`
--

CREATE TABLE `detil_paket` (
  `id_detil_paket` int(11) NOT NULL,
  `PAKET_BELAJAR_id_paket_belajar` int(11) NOT NULL,
  `MATA_PELAJARAN_id_mapel` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `detil_paket`
--

INSERT INTO `detil_paket` (`id_detil_paket`, `PAKET_BELAJAR_id_paket_belajar`, `MATA_PELAJARAN_id_mapel`) VALUES
(231, 10228, 1),
(232, 10227, 3),
(233, 10224, 4),
(234, 10225, 5);

-- --------------------------------------------------------

--
-- Struktur dari tabel `gender`
--

CREATE TABLE `gender` (
  `id_gender` int(11) NOT NULL,
  `gender` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `gender`
--

INSERT INTO `gender` (`id_gender`, `gender`) VALUES
(0, 'Perempuan'),
(1, 'laki-Laki');

-- --------------------------------------------------------

--
-- Struktur dari tabel `guru`
--

CREATE TABLE `guru` (
  `id_guru` int(11) NOT NULL,
  `nama_guru` varchar(30) NOT NULL,
  `no_kontak` int(11) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `speasialisasi` varchar(15) NOT NULL,
  `gender_id_gender` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `guru`
--

INSERT INTO `guru` (`id_guru`, `nama_guru`, `no_kontak`, `alamat`, `speasialisasi`, `gender_id_gender`) VALUES
(1, 'Dimas Evan Rivaldi', 2147483647, 'Tegal', 'Bahasa Inggris', 1),
(2, 'Bambang', 2147483647, 'Tegal', 'Bahasa Indonesi', 1),
(4, 'Shearen rike hasnita', 2147483647, 'Pemalang', 'Matematika', 0),
(5, 'Jheslin anastasya', 2147483647, 'Brebes', 'Fisika', 0),
(6, 'M.Heru setiadi', 2147483647, 'Brebes', 'Kimia', 1),
(7, 'Abadilah', 2147483647, 'Tegal', 'Agama Islam', 1),
(8, 'Iin nafisatun hayat', 2147483647, 'Brebes', 'PKN', 0),
(9, 'Filla abdilah hernaen', 2147483647, 'Brebes', 'Ekonomi', 1),
(10, 'Jihan farah audy', 2147483647, 'Tegal', 'Sosiologi', 0),
(11, 'Nur isti komah', 2147483647, 'Pemalang', 'Matematika', 0),
(12, 'Rafel', 2147483647, 'Pemalang', 'Bahasa Inggris', 1),
(13, 'Della claudia', 2147483647, 'Tegal', 'Bahasa Indonesi', 0),
(14, 'Anne ajeng', 2147483647, 'Brebes', 'Bahasa Jawa', 0),
(15, 'Desvita maharani', 2147483647, 'Tegal', 'Kimia', 0),
(16, 'Refi ananda', 2147483647, 'Brebes', 'Fisika', 1),
(17, 'Fakih agusta', 2147483647, 'Tegal', 'Ekonomi', 1),
(18, 'Mirzan pradani', 2147483647, 'Pemalang', 'Sosiologi', 1),
(19, 'Jeje', 2147483647, 'Tegal', 'PKN', 1),
(20, 'Abella', 2147483647, 'Tegal', 'Bahasa Inggris', 0),
(21, 'Rudi Hakim', 2147483647, 'Tegal', 'Bahasa Jawa', 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `halaman`
--

CREATE TABLE `halaman` (
  `id` int(11) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `kutipan` varchar(255) NOT NULL,
  `isi` text NOT NULL,
  `tgl_isi` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Struktur dari tabel `kbm`
--

CREATE TABLE `kbm` (
  `id_kbm` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `GURU_id_guru` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `kbm`
--

INSERT INTO `kbm` (`id_kbm`, `tanggal`, `GURU_id_guru`) VALUES
(110, '2023-01-30', 9),
(111, '2023-01-31', 21),
(113, '2023-01-25', 10),
(121, '2023-01-19', 12),
(122, '2023-01-16', 6),
(123, '2023-01-09', 5),
(124, '2023-01-24', 11),
(131, '2023-01-18', 7),
(132, '2023-01-10', 4),
(133, '2023-01-17', 8),
(165, '2023-02-01', 20),
(210, '2023-02-02', 19),
(221, '2023-01-12', 1),
(222, '2023-02-06', 18),
(223, '2023-02-07', 17),
(321, '2023-01-11', 2),
(331, '2023-02-08', 16),
(421, '2023-02-14', 13),
(432, '2023-02-13', 14),
(441, '2023-02-09', 15);

-- --------------------------------------------------------

--
-- Struktur dari tabel `kehadiran`
--

CREATE TABLE `kehadiran` (
  `id_kehadiran` int(11) NOT NULL,
  `status_kehadiran` varchar(15) NOT NULL,
  `Kbm_id_kbm` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `kehadiran`
--

INSERT INTO `kehadiran` (`id_kehadiran`, `status_kehadiran`, `Kbm_id_kbm`) VALUES
(10, 'Hadir', 110),
(20, 'Alpa', 111),
(30, 'Sakit', 113),
(40, 'Izin', 121),
(50, 'Hadir', 122),
(60, 'Hadir', 123),
(70, 'Izin', 124),
(80, 'Hadir', 131),
(81, 'Izin', 421),
(82, 'Alpa', 432),
(83, 'Hadir', 441),
(90, 'Sakit', 132),
(91, 'Sakit', 133),
(92, 'Alpa', 165),
(93, 'Alpa', 210),
(94, 'Izin', 221),
(95, 'Hadir', 222),
(96, 'Alpa', 223),
(97, 'Sakit', 321),
(98, 'Izin', 331);

-- --------------------------------------------------------

--
-- Struktur dari tabel `mata_pelajaran`
--

CREATE TABLE `mata_pelajaran` (
  `id_mapel` int(11) NOT NULL,
  `nama_mapel` varchar(15) NOT NULL,
  `GURU_id_guru` int(11) NOT NULL,
  `tingkatan_id_tingkatan` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `mata_pelajaran`
--

INSERT INTO `mata_pelajaran` (`id_mapel`, `nama_mapel`, `GURU_id_guru`, `tingkatan_id_tingkatan`) VALUES
(1, 'Bahasa Inggris', 1, 1),
(2, 'Bahasa Indonesi', 2, 1),
(3, 'Matematika', 4, 1),
(4, 'Fisika', 5, 3),
(5, 'Kimia', 6, 3),
(6, 'Agama Islam', 7, 1),
(7, 'PKN', 8, 1),
(8, 'Ekonomi', 9, 3),
(9, 'Sosiologi', 10, 3),
(10, 'Matematika', 11, 1),
(11, 'Bahasa Inggris', 12, 1),
(12, 'Bahasa Indonesi', 13, 1),
(13, 'Bahasa Jawa', 14, 1),
(14, 'Kimia', 15, 3),
(15, 'Fisika', 16, 3),
(16, 'Ekonomi', 17, 3),
(17, 'Sosiologi', 18, 3),
(18, 'PKN', 19, 1),
(19, 'Bahasa Inggris', 20, 1),
(20, 'Bahasa Jawa', 21, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `order_bimbel`
--

CREATE TABLE `order_bimbel` (
  `id_siswa` int(11) NOT NULL,
  `nama_siswa` varchar(50) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `no_kontak` varchar(15) NOT NULL,
  `gender_id_gender` int(11) NOT NULL,
  `paket_belajar_nama_paket` int(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `order_bimbel`
--

INSERT INTO `order_bimbel` (`id_siswa`, `nama_siswa`, `alamat`, `no_kontak`, `gender_id_gender`, `paket_belajar_nama_paket`) VALUES
(1093768442, 'Wanto', 'Brebes', '085728675441', 1, 10221),
(1873534375, 'Asmara', 'Brebes', '088209478641', 0, 10229),
(1873684141, 'Alvarezel', 'Brebes', '081278645413', 1, 10227);

-- --------------------------------------------------------

--
-- Struktur dari tabel `paket_belajar`
--

CREATE TABLE `paket_belajar` (
  `id_paket_belajar` int(11) NOT NULL,
  `nama_paket` varchar(20) NOT NULL,
  `deskripsi` varchar(50) NOT NULL,
  `biaya_pendidikan` int(11) NOT NULL,
  `tahun_kurikulum` date NOT NULL,
  `lama_studi` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `paket_belajar`
--

INSERT INTO `paket_belajar` (`id_paket_belajar`, `nama_paket`, `deskripsi`, `biaya_pendidikan`, `tahun_kurikulum`, `lama_studi`) VALUES
(10220, 'paket Double', 'Yuk belajar lebih banyak materi', 275000, '2022-06-19', 3),
(10221, 'paket hemat', 'Yuk belajar dengan harga lebih murah', 1000000, '2020-07-09', 2),
(10223, 'paket Hore', 'Yuk belajar senang dengan cara yang lebih mudah', 200000, '2020-06-09', 4),
(10224, 'paket Studifun', 'Belajar dengan beberapa mapel lebih menyenangkan', 150000, '2020-06-09', 3),
(10225, 'paket MathFun', 'Yuk belajar matematika dengan cara yang lebih muda', 200000, '2020-06-09', 4),
(10227, 'paket UN', 'Yuk belajar lebih awal untuk persiapan Ujian Nasio', 450000, '2013-05-06', 12),
(10228, 'paket welcome school', 'Dalam rangka menyambut hari pertama sekolah ,kita ', 250000, '2012-02-12', 5),
(10229, 'paket Special', 'Yuk dapatkan paket spesial segera', 350000, '2022-06-11', 4),
(10230, 'paket Lebaran', 'spesial hari lebaran', 170000, '2021-07-19', 2),
(10231, 'paket Puasa', 'selamat berpuasa', 140000, '2022-04-09', 2);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pilih_paket`
--

CREATE TABLE `pilih_paket` (
  `id_pilih_paket` int(11) NOT NULL,
  `tanggal` date NOT NULL,
  `SISWA_id_siswa` int(11) NOT NULL,
  `PAKET_BELAJAR_id_paket_belajar` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `pilih_paket`
--

INSERT INTO `pilih_paket` (`id_pilih_paket`, `tanggal`, `SISWA_id_siswa`, `PAKET_BELAJAR_id_paket_belajar`) VALUES
(12215, '2021-11-13', 1809549015, 10228),
(12217, '2023-09-11', 1184727400, 10228),
(12225, '2022-04-26', 1313738002, 10227),
(12232, '2022-03-22', 1184728433, 10225),
(12234, '2022-10-25', 1809469129, 10225),
(12236, '2022-03-28', 1184728433, 10225),
(12243, '2022-08-19', 1609529028, 10224),
(12257, '2023-01-14', 1809509019, 10225),
(12265, '2021-09-12', 1109529006, 10224),
(12270, '2022-10-25', 1895220012, 10228),
(12272, '2023-02-11', 1309519031, 10225),
(12274, '2022-04-15', 1209599000, 10224),
(12275, '2022-10-05', 1909529009, 10228),
(12277, '2021-11-12', 1109579010, 10227),
(12280, '2022-06-13', 1609529028, 10227),
(12281, '2023-05-29', 1002956182, 10227),
(12283, '2022-10-19', 1104577102, 10224),
(12286, '2022-10-07', 1809519003, 10224),
(12289, '2023-03-10', 1409559015, 10227),
(12296, '2022-06-13', 1384727481, 10224);

-- --------------------------------------------------------

--
-- Struktur dari tabel `siswa`
--

CREATE TABLE `siswa` (
  `id_siswa` int(11) NOT NULL,
  `nama_siswa` varchar(20) NOT NULL,
  `alamat` varchar(50) NOT NULL,
  `no_kontak` varchar(15) NOT NULL,
  `gender_id_gender` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `siswa`
--

INSERT INTO `siswa` (`id_siswa`, `nama_siswa`, `alamat`, `no_kontak`, `gender_id_gender`) VALUES
(110387132, 'Fatir Sanjaya', 'Brebes Jawa Tengah', '088293648458', 0),
(384627340, 'Setiabudi ', 'Gombong', '085784727481', 1),
(462434647, 'Wina  Khalista', 'Cilacap', '081274964807', 0),
(573957384, 'Galang Setiawan', 'Kebumen', '085784727480', 1),
(756354656, 'Hadi Winata', 'Cilacap', '088274966709', 1),
(1002956134, 'Iksanudin', 'Pemalang', '085874878882', 1),
(1002956154, 'Udin', 'Pemalang', '081274864382', 1),
(1002956182, 'Iksanudin', 'Pemalang', '085874878882', 1),
(1009529006, 'Arobi Noto', 'Cilacap', '088274964807', 1),
(1037865414, 'Ega Hasyim', 'BREBES', '085898657241', 1),
(1074723341, 'Awaliyah', 'Karanganyar', '085774917143', 0),
(1074723361, 'Zahra', 'Karanganyar', '081274917143', 0),
(1074723377, 'Zahratun Awaliyah', 'Karanganyar', '081274917143', 0),
(1104577102, 'Hana Saraswati', 'Kebumen', '085863525909', 0),
(1104577132, 'Nina Sarah', 'Kebumen', '085863525909', 0),
(1104577152, 'Saras', 'Kebumen', '085863525909', 0),
(1109529006, 'Hadi Winoto', 'Cilacap', '081274964807', 1),
(1109529031, 'Hadi Winata', 'Cilacap', '081274964807', 1),
(1109529051, 'Hani', 'Cilacap', '081274964807', 1),
(1109579010, 'Anastasya Rahma', 'Brebes', '08575472472106', 0),
(1109579043, 'Rahma', 'Brebes', '08575472472106', 0),
(1109579063, 'Anis', 'Brebes', '08575472472106', 0),
(1184727400, 'Moh Galang', 'Cirebon', '088264628476', 1),
(1184727437, 'Moh Gilang', 'Cirebon', '088264628476', 1),
(1184727457, 'Moh Guntur', 'Cirebon', '088264628476', 1),
(1184728433, 'Yanuar Galih', 'Karanganyar', '085855783525', 1),
(1184728440, 'Galih', 'Karanganyar', '085855783525', 1),
(1184728460, 'Yayan Galih', 'Karanganyar', '085855783525', 1),
(1204577102, 'Pitaloka Wati', 'Kebumen', '085863525909', 0),
(1209599000, 'Dimas Anggara', 'Semarang', '085745286253', 1),
(1209599049, 'Anggara', 'Semarang', '085745286253', 1),
(1209599069, 'Dimas Saputra', 'Semarang', '085745286253', 1),
(1234567890, 'Ilham', 'Semarang', '085745286253', 1),
(1309519031, 'Cantika', 'Karanganyar', '088274828411', 0),
(1309519047, 'Cantik', 'Karanganyar', '088274828411', 0),
(1309519067, 'Tika', 'Karanganyar', '088274828411', 0),
(1313738002, 'Sandi Wagara', 'Karanganyar', '085863451844', 1),
(1313738039, 'Sandi Segara', 'Karanganyar', '085863451844', 1),
(1313738059, 'Sandi', 'Karanganyar', '085863451844', 1),
(1384727438, 'Muhammad Azmil Yaqin', 'Cirebon', '085684627361', 1),
(1384727458, 'Muhammad Yaqin', 'Cirebon', '085684627361', 1),
(1384727481, 'Muhammad Ainul Yaqin', 'Cirebon', '085684627361', 1),
(1409559015, 'Birli Rahmawati', 'Karanganyar', '085863451844', 0),
(1409559046, 'Rahmawati', 'Karanganyar', '085863451844', 0),
(1409559066, 'Irli Wati', 'Karanganyar', '085863451844', 0),
(1495220012, 'Haura Rahma', 'Purwokerto', '088264625461', 0),
(1609529028, 'Dewi Inayah', 'Karanganyar', '085873526366', 0),
(1609529048, 'Dewi', 'Karanganyar', '085873526366', 0),
(1609529068, 'Dewi Ina', 'Karanganyar', '085873526366', 0),
(1709549015, 'Deski Andriwan', 'Kebumen', '081284727480', 1),
(1789519064, 'Adi Saputra', 'Tegal', '085855783525', 1),
(1809469129, 'Intan Sari', 'Brebes', '085754526463', 0),
(1809469136, 'Intan Naya', 'Brebes', '085754526463', 0),
(1809469156, 'Sari', 'Brebes', '085754526463', 0),
(1809509019, 'Isrinatul Jannah', 'Tegal', '085644725392', 0),
(1809509035, 'Isnatul Jarro', 'Tegal', '085644725392', 0),
(1809509055, 'Isrin', 'Tegal', '085644725392', 0),
(1809519003, 'Aji Saputra', 'Tegal', '085855783525', 1),
(1809519044, 'Aji Sahara', 'Tegal', '085855783525', 1),
(1809549015, 'Gilang Setiawan', 'Kebumen', '081284727480', 1),
(1809549030, 'Galang Setia', 'Kebumen', '081284727480', 1),
(1809549050, 'Gilang', 'Kebumen', '081284727480', 1),
(1809599001, 'Agung Adi Saputra', 'Brebes', '085853527909', 1),
(1809599042, 'Saputra', 'Brebes', '085853527909', 1),
(1809599062, 'Agung', 'Brebes', '085853527909', 1),
(1836546278, 'Budi', 'Brebes Jawa Tengah', '085749026793', 1),
(1895220012, 'Haura Ganasya', 'Purwokerto', '088264625461', 0),
(1909529009, 'Bastian Ramadani', 'Brebes', '088208764788', 1),
(1909529045, 'Ramadani', 'Brebes', '088208764788', 1),
(1938167513, 'Irfan Hakim', 'Brebes', '085892836532', 1),
(1983675314, 'Azkiya Bilqis', 'Gombong', '085820973865', 0),
(2011256292, 'Guntur Ramadani', 'Kuningan', '088212713911', 1),
(2012256292, 'Ajeng Virna Ananta', 'Kuningan', '088219193920', 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `tingkatan`
--

CREATE TABLE `tingkatan` (
  `id_tingkatan` int(11) NOT NULL,
  `nama_tingkatan` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `tingkatan`
--

INSERT INTO `tingkatan` (`id_tingkatan`, `nama_tingkatan`) VALUES
(1, 'SD/MI'),
(2, 'SMP/MTS'),
(3, 'SMA/SMK');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `db_user`
--
ALTER TABLE `db_user`
  ADD PRIMARY KEY (`id_user`);

--
-- Indeks untuk tabel `detil_paket`
--
ALTER TABLE `detil_paket`
  ADD PRIMARY KEY (`id_detil_paket`),
  ADD KEY `detil_paket_MATA_PELAJARAN_FK` (`MATA_PELAJARAN_id_mapel`),
  ADD KEY `detil_paket_PAKET_BELAJAR_FK` (`PAKET_BELAJAR_id_paket_belajar`);

--
-- Indeks untuk tabel `gender`
--
ALTER TABLE `gender`
  ADD PRIMARY KEY (`id_gender`);

--
-- Indeks untuk tabel `guru`
--
ALTER TABLE `guru`
  ADD PRIMARY KEY (`id_guru`),
  ADD KEY `GURU_gender_FK` (`gender_id_gender`);

--
-- Indeks untuk tabel `halaman`
--
ALTER TABLE `halaman`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `kbm`
--
ALTER TABLE `kbm`
  ADD PRIMARY KEY (`id_kbm`),
  ADD KEY `Kbm_GURU_FK` (`GURU_id_guru`);

--
-- Indeks untuk tabel `kehadiran`
--
ALTER TABLE `kehadiran`
  ADD PRIMARY KEY (`id_kehadiran`),
  ADD KEY `Kehadiran_Kbm_FK` (`Kbm_id_kbm`);

--
-- Indeks untuk tabel `mata_pelajaran`
--
ALTER TABLE `mata_pelajaran`
  ADD PRIMARY KEY (`id_mapel`),
  ADD KEY `MATA_PELAJARAN_GURU_FK` (`GURU_id_guru`),
  ADD KEY `MATA_PELAJARAN_tingkatan_FK` (`tingkatan_id_tingkatan`);

--
-- Indeks untuk tabel `order_bimbel`
--
ALTER TABLE `order_bimbel`
  ADD PRIMARY KEY (`id_siswa`),
  ADD KEY `gender_id_gender` (`gender_id_gender`),
  ADD KEY `id_paket_belajar` (`paket_belajar_nama_paket`),
  ADD KEY `paket_belajar_id_paket_belajar` (`paket_belajar_nama_paket`);

--
-- Indeks untuk tabel `paket_belajar`
--
ALTER TABLE `paket_belajar`
  ADD PRIMARY KEY (`id_paket_belajar`);

--
-- Indeks untuk tabel `pilih_paket`
--
ALTER TABLE `pilih_paket`
  ADD PRIMARY KEY (`id_pilih_paket`),
  ADD KEY `Pilih_paket_PAKET_BELAJAR_FK` (`PAKET_BELAJAR_id_paket_belajar`),
  ADD KEY `Pilih_paket_SISWA_FK` (`SISWA_id_siswa`);

--
-- Indeks untuk tabel `siswa`
--
ALTER TABLE `siswa`
  ADD PRIMARY KEY (`id_siswa`),
  ADD KEY `SISWA_gender_FK` (`gender_id_gender`) USING BTREE;

--
-- Indeks untuk tabel `tingkatan`
--
ALTER TABLE `tingkatan`
  ADD PRIMARY KEY (`id_tingkatan`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `db_user`
--
ALTER TABLE `db_user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `halaman`
--
ALTER TABLE `halaman`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT untuk tabel `order_bimbel`
--
ALTER TABLE `order_bimbel`
  MODIFY `id_siswa` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1875346222;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `detil_paket`
--
ALTER TABLE `detil_paket`
  ADD CONSTRAINT `detil_paket_MATA_PELAJARAN_FK` FOREIGN KEY (`MATA_PELAJARAN_id_mapel`) REFERENCES `mata_pelajaran` (`id_mapel`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `detil_paket_PAKET_BELAJAR_FK` FOREIGN KEY (`PAKET_BELAJAR_id_paket_belajar`) REFERENCES `paket_belajar` (`id_paket_belajar`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `guru`
--
ALTER TABLE `guru`
  ADD CONSTRAINT `GURU_gender_FK` FOREIGN KEY (`gender_id_gender`) REFERENCES `gender` (`id_gender`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `kbm`
--
ALTER TABLE `kbm`
  ADD CONSTRAINT `Kbm_GURU_FK` FOREIGN KEY (`GURU_id_guru`) REFERENCES `guru` (`id_guru`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `kehadiran`
--
ALTER TABLE `kehadiran`
  ADD CONSTRAINT `Kehadiran_Kbm_FK` FOREIGN KEY (`Kbm_id_kbm`) REFERENCES `kbm` (`id_kbm`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `mata_pelajaran`
--
ALTER TABLE `mata_pelajaran`
  ADD CONSTRAINT `MATA_PELAJARAN_GURU_FK` FOREIGN KEY (`GURU_id_guru`) REFERENCES `guru` (`id_guru`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `MATA_PELAJARAN_tingkatan_FK` FOREIGN KEY (`tingkatan_id_tingkatan`) REFERENCES `tingkatan` (`id_tingkatan`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `pilih_paket`
--
ALTER TABLE `pilih_paket`
  ADD CONSTRAINT `Pilih_paket_PAKET_BELAJAR_FK` FOREIGN KEY (`PAKET_BELAJAR_id_paket_belajar`) REFERENCES `paket_belajar` (`id_paket_belajar`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `Pilih_paket_SISWA_FK` FOREIGN KEY (`SISWA_id_siswa`) REFERENCES `siswa` (`id_siswa`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Ketidakleluasaan untuk tabel `siswa`
--
ALTER TABLE `siswa`
  ADD CONSTRAINT `SISWA_gender_FK` FOREIGN KEY (`gender_id_gender`) REFERENCES `gender` (`id_gender`) ON DELETE NO ACTION ON UPDATE NO ACTION;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
