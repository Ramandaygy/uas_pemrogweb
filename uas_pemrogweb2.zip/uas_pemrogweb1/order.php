<?php
session_start();
$_SESSION['navigation'] = "1";
@include 'navbar.php';

$conn = mysqli_connect('localhost','root','','bimbel');

?>
<div class="row">
    <div class="col-lg-12 d-flex align-items-stretch">
        <div class="card w-100">
            <div class="card-body p-4">
                <h5 class="card-title fw-semibold mb-4">Data Pendaftaran Bimbel</h5>
                <div class="table-responsive">
                    <table class="table text-nowrap mb-0 align-middle">
                        <thead class="text-dark fs-4">
                            <tr>
                                <th class="border-bottom-0">
                                    <h6 class="fw-semibold mb-0">NIS</h6>
                                </th>
                                <th class="border-bottom-0">
                                    <h6 class="fw-semibold mb-0">Nama</h6>
                                </th>
                                <th class="border-bottom-0">
                                    <h6 class="fw-semibold mb-0">Alamat</h6>
                                </th>
                                <th class="border-bottom-0">
                                    <h6 class="fw-semibold mb-0">Nomer Telepon</h6>
                                </th>
                                <th class="border-bottom-0">
                                    <h6 class="fw-semibold mb-0">Gender</h6>
                                </th>
                                <th class="border-bottom-0">
                                    <h6 class="fw-semibold mb-0">Nama Paket</h6>
                                </th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php 
                            $result = mysqli_query($conn, "SELECT * FROM order_bimbel ");
                            $iteration = 1;
                            while ($member = mysqli_fetch_array($result)) {
                            ?>
                            <tr>
                                <td class="border-bottom-0">
                                    <h6 class="fw-semibold mb-1"><?= $member['id_siswa'] ?></h6>
                                </td>
                                <td class="border-bottom-0">
                                    <h6 class="fw-semibold mb-1"><?= $member['nama_siswa'] ?></h6>
                                </td>
                                <td class="border-bottom-0">
                                    <p class="mb-0 fw-normal"><?= substr($member['alamat'], 0, 40) . '...' ?></p>
                                </td>
                                <td class="border-bottom-0">
                                    <h6 class="fw-semibold mb-0 fs-4"><?= $member['no_kontak'] ?></h6>
                                </td>
                                <td class="border-bottom-0">
                                    <div class="d-flex align-items-center gap-2">
                                        <?php if($member['gender_id_gender']==="0"){?>
                                        <span class="badge bg-primary rounded-3 fw-semibold"
                                            style="width: 140px;">PEREMPUAN</span>
                                        <?php } else { ?>
                                        <span class="badge bg-success rounded-3 fw-semibold" style="width: 140px;">LAKI
                                            -LAKI</span>
                                        <?php } ?>
                                    </div>
                                </td>
                                <td class="border-bottom-0">
                                    <h6 class="fw-semibold mb-0 fs-4"><?= $member['paket_belajar_nama_paket'] ?></h6>
                                </td>
                            </tr>
                            <?php 
                            $iteration ++;
                            }?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>


<?php
@include("footer.php");
?>