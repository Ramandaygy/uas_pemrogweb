<?php
//koneksi database
$server = "localhost";
$user = "root";
$password = "";
$database = "bimbel";

//buat koneksi
$koneksi = mysqli_connect($server, $user, $password, $database) or die(mysqli_error($koneksi));

//memulai sesi
session_start();

//jika tombol simpan diklik
if (isset($_POST['bsimpan'])) {
    //pengujian apakah data akan di edit atau disimpan baru
    if (isset($_GET['hal']) && $_GET['hal'] == "edit") {
        //data akan di edit
        $edit = mysqli_query($koneksi, "UPDATE guru SET nama_guru = '$_POST[tnama]', no_kontak = '$_POST[tno]', alamat = '$_POST[talamat]', speasialisasi = '$_POST[tspeasialisasi]', gender_id_gender = '$_POST[tgender]' WHERE id_guru = '$_GET[id]' ");

        //uji jika edit data sukses
        if ($edit) {
            echo "<script>
                alert('Edit data Sukses!');
                window.location.href = 'guru_page.php';
                </script>";
        } else {
            echo "<script>
                alert('Edit data Gagal!');
                window.location.href = 'guru_page.php';
                </script>";
        }
    } else {
        //Data akan disimpan baru
        $simpan = mysqli_query($koneksi, "INSERT INTO guru (nama_guru, no_kontak, alamat, speasialisasi, gender_id_gender)
                                            VALUE ('$_POST[tnama]', '$_POST[tno]', '$_POST[talamat]', '$_POST[tspeasialisasi]', '$_POST[tgender]')");
        //uji jika simpan data sukses
        if ($simpan) {
            echo "<script>
                alert('Simpan data Sukses!');
                window.location.href = 'guru_page.php';
                </script>";
        } else {
            echo "<script>
                alert('Simpan data Gagal!');
                window.location.href = 'guru_page.php';
                </script>";
        }
    }
}

//Deklarasi variabel untuk menampung data yang akan di edit
$vid = "";
$vnama = "";
$vno = "";
$valamat = "";
$vspeasialisasi = "";
$vgender = "";

//pengujian jika tombol edit/hapus diklik
if (isset($_GET['hal'])) {
    //pengujian jika edit data
    if ($_GET['hal'] == "edit") {
        //tampilkan data yang akan di edit
        $tampil = mysqli_query($koneksi, "SELECT * FROM guru WHERE id_guru = '$_GET[id]' ");
        $data = mysqli_fetch_array($tampil);
        if ($data) {
            //jika data ditemukan maka data di tampung ke dalam variabel
            $vid = $data['id_guru'];
            $vnama = $data['nama_guru'];
            $vno = $data['no_kontak'];
            $valamat = $data['alamat'];
            $vspeasialisasi = $data['speasialisasi'];
            $vgender = $data['gender_id_gender'];
        }
    }
}

//pengujian jika tombol delete diklik
if (isset($_POST['delete'])) {
    $id = $_POST['id_guru'];

    try {
        // Attempt to delete the member record
        $delete_guru = mysqli_query($koneksi, "DELETE FROM guru WHERE id_guru = '$id'");

        if ($delete_guru) {
            echo "<script>
                alert('Hapus data Sukses!');
                window.location.href = 'guru_page.php';
                </script>";
        } else {
            throw new Exception("Gagal menghapus data guru");
        }
    } catch (Exception $e) {
        // Handle the exception and set an appropriate error message
        echo "<script>
            alert('Gagal menghapus data Guru');
            window.location.href = 'guru_page.php';
            </script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>DATA GURU</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>

<body>
    <div class="container">
        <h3 class="text-center">DATA GURU</h3>
        <h3 class="text-center">NEW PRIMAGAMA</h3>

        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="card">
                    <div class="card-header bg-info text-light">
                        FORM INPUT DATA GURU
                    </div>
                    <div class="card-body">
                        <form method="POST">
                            <div class="mb-3">
                                <label class="form-label">ID Guru</label>
                                <input type="text" name="tid" value="<?= $vid ?>" class="form-control" placeholder="Masukan ID guru">
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Nama</label>
                                <input type="text" name="tnama" value="<?= $vnama ?>" class="form-control" placeholder="Masukan Nama">
                            </div>

                            <div class="mb-3">
                                <label class="form-label">No Kontak</label>
                                <input type="text" name="tno" value="<?= $vno ?>" class="form-control" placeholder="Masukan No Kontak">
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Alamat</label>
                                <input type="text" name="talamat" value="<?= $valamat ?>" class="form-control" placeholder="Masukan Alamat">
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Speasialisasi</label>
                                <input type="text" name="tspeasialisasi" value="<?= $vspeasialisasi ?>" class="form-control" placeholder="Masukan Speasialisasi">
                            </div>

                            <div class="mb-3">
                                <label class="form-label">Gender</label>
                                <select class="form-select" name="tgender">
                                    <option value="<?= $vgender ?>"><?= $vgender ?></option>
                                    <option value="0">Perempuan</option>
                                    <option value="1">Laki-laki</option>
                                </select>
                            </div>
                    </div>
                    <div class="text-center">
                        <hr>
                        <button class="btn btn-primary" name="bsimpan" type="submit">Simpan</button>
                    </div>
                    <div class="card-footer bg-info"></div>
                </div>
            </div>
            </form>

            <div class="card mt-3">
                <div class="card-header bg-info text-light">
                    DATA GURU
                </div>
                <table class="table table-striped table-hover table-bordered">
                    <tr>
                        <th>ID Guru</th>
                        <th>Nama</th>
                        <th>No Kontak</th>
                        <th>Alamat</th>
                        <th>Speasialisasi</th>
                        <th>Gender</th>
                        <th>Aksi</th>
                    </tr>
                    <?php
                    //persiapan menampilkan data
                    $no = 1;

                    //untuk pencarian data
                    //jika tombol cari diklik
                    if (isset($_POST['bcari'])) {
                        //tampilkan data yang dicari
                        $keyword = $_POST['tcari'];
                        $q = "SELECT * FROM guru order by id_guru asc";
                    } else {
                        $q = "SELECT * FROM guru order by id_guru asc";
                    }
                    $tampil = mysqli_query($koneksi, $q);
                    while ($data = mysqli_fetch_array($tampil)) {
                    ?>

                        <tr>
                            <td><?= $no++ ?></td>
                            <td><?= $data['nama_guru'] ?></td>
                            <td><?= $data['no_kontak'] ?></td>
                            <td><?= $data['alamat'] ?></td>
                            <td><?= $data['speasialisasi'] ?></td>
                            <td><?= ($data['gender_id_gender'] == 0) ? 'Perempuan' : 'Laki-laki' ?></td>
                            <td>
                                <a href="guru_page.php?hal=edit&id=<?= $data['id_guru'] ?>" class="btn btn-warning">Edit</a>
                            </td>
                            <td>
                                <form method="POST" action="guru_page.php">
                                    <input type="hidden" name="id_guru" value="<?= $data['id_guru'] ?>">
                                    <button class="btn btn-danger" name="delete" type="submit" onclick="return confirm('Apakah anda yakin akan hapus Data ini?')">Hapus</button>
                                </form>
                            </td>
                        </tr>

                    <?php } ?>
                </table>
            </div>
            <div class="card-footer bg-info"></div>
            <!-- Tombol kembali ke halaman utama -->
            <div class="mt-3">
                <a href="home_admin.php" class="btn btn-primary">Kembali ke Halaman Utama</a>
            </div>
        </div>
    </div>
    </div>
    </form>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>

</html>