<?php

@include 'config.php';

session_start();

if(!isset($_SESSION['user_name'])){
   header('location:login_form.php');
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Bimbel</title>
    <link rel="stylesheet" href="style2.css">
</head>
<body>
    <nav>
        <div class="wrapper">
            <div class="logo"><a href=''>New Primagama</a></div>
            <div class="menu">
                <ul>
                    <li><a href="#home">Home</a></li>
                    <li><a href="#courses">Paket Belajar</a></li>
                    <li><a href="Daftar.php">Daftar</a></li>
                    <li><a href="#contact">Contact</a></li>
                    <li><a href="logout.php" class="tbl-biru">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <div class="wrapper">
        <!-- untuk home -->
        <section id="home">
            <img src="img/bimbel2.png"/>
            <div class="kolom">
                <p class="deskripsi">Sahabat Untuk Menjadi Cerdas</p>
                <h2>Bimbingan Belajar Antusias</h2>
                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Nesciunt, nobis.</p>
                <p><a href="" class="tbl-pink">Pelajari Lebih Lanjut</a></p>
            </div>
        </section>

         <!-- untuk courses -->
         <section id="courses">
            <div class="kolom">
                <p class="deskripsi">You Will Need This</p>
                <h2>Study Package</h2>
                <p>New Primagama menawarkan paket belajar yang komprehensif, melibatkan siswa dengan materi terkini dan metode pembelajaran interaktif. Setiap siswa mendapatkan panduan belajar pribadi yang disesuaikan, sementara dukungan tutor berpengalaman memastikan pemahaman konsep-konsep kunci.</p>
                <p>New Primagama menawarkan beragam pilihan dengan adanya 8 paket belajar yang dirancang khusus. Setiap paket dilengkapi dengan materi pembelajaran terbaru, panduan belajar yang disesuaikan, dan dukungan tutor berpengalaman, memastikan bahwa setiap siswa dapat menemukan solusi pembelajaran yang sesuai dengan kebutuhan mereka.
                   Diantaranya Paket Double,Paket Hemat,Paket Hore Dll</p>
                <p><a href="" class="tbl-biru">Pelajari Lebih Lanjut</a></p>
            </div>
            <img src="img/case-study.png"/>
        </section>


    <div id="contact">
        <div class="wrapper">
            <div class="footer">
                <div class="footer-section">
                    <h3>New Primagama.</h3>
                    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sint, culpa!</p>
                </div>
                <div class="footer-section">
                    <h3>About</h3>
                    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sint, culpa!</p>
                </div>
                <div class="footer-section">
                    <h3>Contact</h3>
                    <p>Jl. Laksda Adisucipto Sleman Yogyakarta</p>
                    <p>Kode Pos: 57365</p>
                </div>
                <div class="footer-section">
                    <h3>Social</h3>
                    <p><b>YouTube: </b>New Primagama</p>
                </div>
            </div>
        </div>
    </div>

    <div id="copyright">
        <div class="wrapper">
            &copy; 2024. <b>New Primagama.</b> All Rights Reserved.
        </div>
    </div>
    
</body>
</html>